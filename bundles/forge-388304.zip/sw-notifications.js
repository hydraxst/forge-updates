/* Forge — extensions du service worker (importées par le service worker généré par Workbox).
 * - clic sur une notification : ouvre l'app sur la bonne page ;
 * - synchronisation périodique (Chrome Android, app installée) : délivre les rappels échus
 *   que l'app a préparés dans IndexedDB, même si elle n'est pas ouverte.
 */

self.addEventListener('notificationclick', (event) => {
  event.notification.close()
  const url = (event.notification.data && event.notification.data.url) || '/'
  event.waitUntil(
    (async () => {
      const windows = await self.clients.matchAll({ type: 'window', includeUncontrolled: true })
      for (const client of windows) {
        if ('focus' in client) {
          await client.focus()
          if ('navigate' in client) {
            try {
              await client.navigate(url)
            } catch (e) {
              /* page non contrôlée : on garde la page actuelle */
            }
          }
          return
        }
      }
      await self.clients.openWindow(url)
    })(),
  )
})

self.addEventListener('periodicsync', (event) => {
  if (event.tag === 'forge-reminders') event.waitUntil(deliverDueReminders())
})

// Même base IndexedDB que la bibliothèque idb-keyval utilisée par l'app.
function withStore(mode, fn) {
  return new Promise((resolve, reject) => {
    const open = indexedDB.open('keyval-store')
    open.onupgradeneeded = () => open.result.createObjectStore('keyval')
    open.onerror = () => reject(open.error)
    open.onsuccess = () => {
      const tx = open.result.transaction('keyval', mode)
      const req = fn(tx.objectStore('keyval'))
      tx.oncomplete = () => resolve(req && req.result)
      tx.onerror = () => reject(tx.error)
    }
  })
}
const idbGet = (key) => withStore('readonly', (store) => store.get(key))
const idbSet = (key, value) => withStore('readwrite', (store) => store.put(value, key))

async function deliverDueReminders() {
  const reminders = (await idbGet('forge-reminders')) || []
  const delivered = new Set((await idbGet('forge-sw-delivered')) || [])
  const now = Date.now()
  const due = reminders.filter((r) => r.at <= now && r.at > now - 6 * 3600 * 1000 && !delivered.has(r.id))
  for (const r of due.slice(-3)) {
    await self.registration.showNotification(r.title, {
      body: r.body,
      tag: r.id,
      icon: '/pwa-192x192.png',
      badge: '/pwa-64x64.png',
      data: { url: r.url },
    })
    delivered.add(r.id)
  }
  await idbSet('forge-sw-delivered', Array.from(delivered).slice(-300))
}
